if(FALSE) {

  library(tidytensor)
  test3d <- tt(array(1:(2*5*6), dim = c(2, 5, 6)))
  print(test3d, bottom = "3d")



}
