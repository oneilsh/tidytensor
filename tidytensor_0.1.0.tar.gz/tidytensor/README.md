# TidyTensor

This is a stub readme, more soon.
