if(FALSE) {

library(tidytensor)

ct <- function(...) {
  cat(..., sep = "")
}


comma <-function(...) {
  return(paste0(..., collapse = ", "))
}

cat_indent <- function(size = 1, is.tensor = TRUE) {
  if(!is.tensor) {
    for(i in rep(0, size)) {
      ct("|  ")
    }
  } else {
    for(i in rep(0, max(0, size))) {
      ct("|  ")
    }
    #ct("+--")
    ct("# ")
  }
}

nicecolnames <- function(m, predims = 1, postdims = 0, max_cols = 6) {
  colnames <- as.character(1:ncol(m))
  if(!is.null(colnames(m))) {
    if(!all(is.na(colnames(m)))) {
      colnames <- paste0('"', colnames(m), '"' , sep = "")
    }
  }


  res <- rep("[", length(colnames))
  commas_pre <- paste0(rep(",", predims), collapse = "")
  commas_post <- paste0(rep(",", postdims), collapse = "")
  res <- paste0(res, commas_pre, colnames, commas_post, "]", sep = "")
  if(length(res) > max_cols) {
    res <- res[1:max_cols]
    res <- c(res, "...")
  }
  return(res)
}

nicerownames <- function(m, predims = 0, postdims = 1, max_rows = 6) {
  rownames <- as.character(1:nrow(m))
  if(!is.null(rownames(m))) {
    if(!all(is.na(rownames(m)))) {
      rownames <- paste0('"', rownames(m), '"' , sep = "")
    }
  }

  res <- rep("[", length(rownames))
  commas_pre <- paste0(rep(",", predims), collapse = "")
  commas_post <- paste0(rep(",", postdims), collapse = "")
  res <- paste0(res, commas_pre, rownames, commas_post, "]", sep = "")
  if(length(res) > max_rows) {
    res <- res[1:max_rows]
    res <- c(res, "...")
  }

  return(res)
}

space_fill <- function(charvec) {
  max_chars <- max(nchar(charvec))
  format <- paste0("%", max_chars, "s", collapse = "")
  res <- sprintf(format, charvec)
  return(res)
}

# returns a set of formatted lines (as a character vector)
nicemat <- function(m, show_row_names = TRUE, show_col_names = TRUE, row_predims = 0, row_postdims = 1, col_predims = 1, col_postdims = 0, max_rows = 6, max_cols = 6) {
  # sigh... apply returns a vector in some cases; if it does so this function fixes it back to a matrix
  fix <- function(x) {
    if(!is.matrix(x)) {
      return(t(as.matrix(x)))
    } else {
      return(x)
    }
  }

  m_char <- fix(apply(m, 2, as.character))
  if(nrow(m_char) > max_rows) {
    m_char <- m_char[1:max_rows, , drop = FALSE]
    dots <- rep("...", ncol(m_char))
    m_char <- rbind(m_char, dots, deparse.level = 0)
  }
  if(ncol(m_char) > max_cols) {
    m_char <- m_char[, 1:max_cols, drop = FALSE]
    dots <- rep("...", nrow(m_char))
    m_char <- cbind(m_char, dots)
  }

  if(show_col_names) {
    col_names <- nicecolnames(m, predims = col_predims, postdims = col_postdims, max_cols = max_cols)
    m_char <- rbind(col_names, m_char, deparse.level = 0)
  }
  if(show_row_names) {
    row_names <- nicerownames(m, predims = row_predims, postdims = row_postdims, max_rows = max_rows)
    if(show_col_names) {
      m_char <- cbind(c("", row_names), m_char)
    } else {
      m_char <- cbind(row_names, m_char)
    }
  }
  m_char <- fix(apply(m_char, 2, space_fill))
  collapserow <- function(row) {
    return(paste0(row, collapse = "  "))
  }
  m_char <- fix(apply(m_char, 1, collapserow))
  return(m_char)
}



print_1d_bottom <- function(t, end_n = 6, show_names = TRUE, indent = 0, signif_digits = 3, ...) {
  if(is.null(dim(t))) {stop("print_1d_bottom called on object t without dim(t).")}
  shape <- dim(t)
  t <- signif(t, signif_digits)
  if(length(shape) == 1) {
    #ct(rep(" ", indent))
    cat_indent(size = indent, is.tensor = TRUE)
    ct("Rank 1 tensor, shape: (", shape, ")")
    if(!is.null(ranknames(t))) {
      ct(", ranknames: ")
      ct(comma(ranknames(t)))
    }
    ct("\n")
    lines <- nicemat(t(as.matrix(t)), show_col_names = show_names, show_row_names = FALSE, col_predims = 0, max_cols = end_n)
    for(line in lines) {
      #ct(rep(" ", indent))
      cat_indent(size = indent, is.tensor = FALSE)
      cat("   ", line, "\n")
    }
  } else {
    stop("print_1d_bottom called on object t with length(dim(t)) != 1.")
  }
}

print_2d_bottom <- function(t, max_rows = 6, max_cols = 6, show_names = TRUE, indent = 0, signif_digits = 3, ...) {
  if(is.null(dim(t))) {stop("print_2d_bottom called on object t without dim(t).")}
  shape <- dim(t)
  t <- signif(t, signif_digits)
  if(length(shape) == 2) {
    #ct(rep(" ", indent))
    cat_indent(size = indent, is.tensor = TRUE)
    ct("Rank 2 tensor, shape: (", comma(shape), ")")
    if(!is.null(ranknames(t))) {
      ct(", ranknames: ")
      ct(comma(ranknames(t)))
    }
    ct("\n")
    lines <- nicemat(t, show_col_names = show_names, show_row_names = show_names, max_rows = max_rows, max_cols = max_cols)
    for(line in lines) {
      #ct(rep(" ", indent))
      cat_indent(size = indent, is.tensor = FALSE)
      cat("   ", line, "\n")
    }
  } else {
    stop("print_2d_bottom called on object t with length(dim(t)) != 2.")
  }
}



print_3d_bottom <- function(t, max_rows = 6, max_cols = 6, max_depth = 3, show_names = TRUE, indent = 0, signif_digits = 3, ...) {
  if(is.null(dim(t))) {stop("print_3d_bottom called on object t without dim(t).")}
  shape <- dim(t)
  t <- signif(t, signif_digits)
  if(length(shape) == 3) {
    #ct(rep(" ", indent))
    cat_indent(size = indent, is.tensor = TRUE)

    ct("Rank 3 tensor, shape: (", comma(shape), ")")
    if(!is.null(ranknames(t))) {
      ct(", ranknames: ")
      ct(comma(ranknames(t)))
    }
    if(shape[3] > max_depth) {
      t <- t[, , 1:(max_depth+1), drop = FALSE]
      t[, , max_depth + 1] <- "..."
    }
    recast <- apply(t, c(1,2), comma)
    bracketed <- paste0("[", recast, "]")
    bracketed <- array(bracketed, dim = shape[1:2])
    if(!is.null(dimnames(t))) {
      dimnames(bracketed)[[1]] <- dimnames(t)[[1]]
      dimnames(bracketed)[[2]] <- dimnames(t)[[2]]
      if(any(!is.na(dimnames(t)[[3]]))) {
        ct(" (bottom dimnames: ")
        dn <- paste0('"', dimnames(t)[[3]], '"')
        ct(comma(dn))
        ct(")")
      }
    }
    ct("\n")
    lines <- nicemat(bracketed, show_col_names = show_names, show_row_names = show_names, max_rows = max_rows, max_cols = max_cols, row_postdims = 2, col_postdims = 1)
    for(line in lines) {
      #ct(rep(" ", indent))
      cat_indent(size = indent, is.tensor = FALSE)
      cat("   ", line, "\n")
    }
  } else {
    stop("print_3d_bottom called on object t with length(dim(t)) != 3.")
  }
}

rnorm(6*6*4) %>% array(dim = c(6, 6, 4)) %>% tt() %>%
  set_ranknames(a, b, c) %>%
  set_dimnames_for_rank(1, .dots = letters[1:6]) %>%
  set_dimnames_for_rank(c, .dots = letters[1:4]) %>%
  print_3d_bottom(max_cols = 3, show_names = T)


1:(8*10) %>% array(dim = c(8, 10)) %>% tt() %>%
  set_ranknames(one, two) %>%
  set_dimnames_for_rank(one, .dots = letters[1:8]) %>%
  print_2d_bottom(show_names = T)




print2 <- function(t,  show_names = TRUE, max_per_level = 1, bottom = "auto", max_rows = 6, max_cols = 6, max_depth = 3, signif_digits = 3, indent = 0, ...) {
  if(bottom == "auto") {
    bottom = "1d"
    if(length(dim(t)) > 2) { # could be 3d
      if(dim(t)[length(dim(t))] %in% c(3, 1)) {          # looks like channels-first...
        bottom = "3d"
      } else if(dim(t)[length(dim(t))-2] %in% c(3, 1)) { # looks like channels-first... OR the lst two dimensions are exactly equal
        bottom = "2d"
      }
    }
    if(length(dim(t)) >= 2) {
      if((dim(t)[length(dim(t))] == dim(t)[length(dim(t)) - 1]) & dim(t)[length(dim(t))] > 3) { # if the last two are exactly equal, and greader than 3
        bottom = "2d"
      }
    }
  }

  shape <- dim(t)
  if(bottom == "1d" & length(shape) == 1) {
    print_1d_bottom(t, end_n = max_rows, show_names = show_names, indent = indent, signif_digits = signif_digits, ...)
    return(invisible())
  }
  if(bottom == "2d" & length(shape) == 2) {
    print_2d_bottom(t, max_rows = max_rows, max_cols = max_cols, show_names = show_names, indent = indent, signif_digits = signif_digits, ...)
    return(invisible())
  }
  if(bottom == "3d" & length(shape) == 3) {
    print_3d_bottom(t, max_rows = max_rows, max_cols = max_cols, max_depth = max_depth, show_names = show_names, indent = indent, signif_digits = signif_digits, ...)
    return(invisible())
  }

  cat_indent(size = indent, is.tensor = TRUE)
  #ct(rep("| ", indent/2))
  ct("Rank ", length(shape) , " tensor, shape: (", comma(shape), ")")
  if(!is.null(ranknames(t))) {
    ct(", ranknames: ")
    ct(comma(ranknames(t)))
  }
  ct("\n")

  for(i in 1:max_per_level) {
    subt <- tt_index(t, i, dimension = 1, drop = TRUE) # equiv of t[i, , , ] for a rank-4 tensor, but we don't know the rank hence calling tt_index
    print2(subt,  show_names = show_names, max_per_level = max_per_level, bottom = bottom, max_rows = max_rows, max_cols = max_cols, max_depth = max_depth, signif_digits = signif_digits, indent = indent + 1, ...)
  }
  cat_indent(size = indent+1, is.tensor = FALSE)
  #left <- dim(t)[1] - max_per_level
  #ct("# (and", left, "more Rank", length(dim(t))-1, "tensors ...)", color = crayon::make_style("#BBBBBB"))
  ct("# ...")
  ct("\n")

}

runif(1:(4*5*1*7*5)) %>%
  array(dim = c(4, 5, 1, 7, 5)) %>%
  tt() %>%
  set_ranknames(one, two, three, four, five) %>%
  set_dimnames_for_rank(one, .dots = letters[1:4]) %>%
  set_dimnames_for_rank(two, .dots = letters[1:5]) %>%
  set_dimnames_for_rank(four, .dots = letters[1:7]) %>%
  print2(show_names = F, bottom = "2d", max_per_level = 1)



} # end if(FALSE)
