# TidyTensor - More Fun with Deep Learning

TidyTensor is a package for inspecting and manipulating tensors (multidimensional arrays) in R. 
