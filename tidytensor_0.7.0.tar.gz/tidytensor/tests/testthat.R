library(testthat)
library(tidytensor)

test_check("tidytensor")
